
/*
 * Made by Tony Pan for University Liggett School Middle School's robotics team
 * 9/21/17
 * 
 * File: BallMover.java
 * ---------------------
 * This program displays a ball on the graphics window. The ball follows the movement
 * of the mouse. When the mouse is clicked, the ball change to a random color.
 * 
 */

import java.awt.Color;
import java.awt.event.MouseEvent;

import acm.program.GraphicsProgram;
import stanford.cs106.util.RandomGenerator;

public class BallMover extends GraphicsProgram {

	private static final int DIAMETER = 100;
	private static final int LATENCY = 1;
	// The separation time between each ball movement

	private Ball ball = null;	// declares the ball object

	public static void main(String[] args) {
		(new BallMover()).start(args);
	}
	
	/*
	 * This method initializes the ball object
	 * 
	 */
	public void init() {
		ball = new Ball(DIAMETER, DIAMETER); // creates a new ball of the chosen size
		ball.setFilled(true);
		ball.setColor(Color.RED);
	}

	
	/*
	 * This method adds the ball to the graphics window
	 * 
	 */
	public void run() {
		add(ball, (getWidth() - ball.getWidth()) / 2, (getHeight() - ball.getHeight()) / 2);
	}

	
	/*
	 * This method follows the movement of the mouse and update the location of the ball
	 * 
	 */
	public void mouseMoved(MouseEvent event) {
		remove(ball);
		add(ball, event.getX() - ball.getWidth() / 2, event.getY() - ball.getHeight() / 2);
		pause(LATENCY);
	}

	/*
	 * This method calls to change the color of the ball every time the mouse is clicked
	 * 
	 */
	public void mouseClicked(MouseEvent event) {
		changeColor();
	}

	
	/*
	 * This method generates a random color to set the ball to
	 * 
	 */
	private void changeColor() {
		Color color = RandomGenerator.getInstance().nextColor();
		ball.setColor(color);
	}

}
