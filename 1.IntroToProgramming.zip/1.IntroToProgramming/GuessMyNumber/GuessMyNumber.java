
/*
 * Made by Tony Pan for University Liggett School Middle School's robotics team
 * 9/10/17
 * 
 * File: GuessMyNumber.java
 * ---------------------
 * This program randomly generates a number between 1 and 100 and prompts 
 * the user to guess it. The computer will give hints to whether the guesses
 * are too big or too small. The program keeps running until the user can 
 * guess the right number.
 * 
 */

import acm.program.*;
import stanford.cs106.util.RandomGenerator;

public class GuessMyNumber extends ConsoleProgram {

	// The range of the secret number
	private static final int MIN_NUM = 1;
	private static final int MAX_NUM = 200;

	private int gameCount = 0;
	private int minGuess = MAX_NUM;
	private int maxGuess = MIN_NUM;

	public static void main(String[] args) {
		(new GuessMyNumber()).start(args);
	}
	
	/*
	 * This is the main method that refers to different methods to play the game The
	 * game goes on until the user decides not to play again
	 * 
	 */
	public void run() {
		intro();
		boolean playAgain = readBoolean("Play the game? (yes or no)", "yes", "no");
		while (playAgain) {
			playOneGame();
			gameCount++;
			playAgain = readBoolean("Play the game?", "yes", "no");
		}
		if (!playAgain) {
			displayStats();
		}
	}

	private void intro() {
		println("Welcome to the guessing game");
		println("I will guess a number between " + MIN_NUM + " and " + MAX_NUM);
		println("You will try to guess it");
		println("Enjoy!");
		println();
	}

	/*
	 * This method allows the user to play one turn of the guessing game
	 * 
	 */
	private void playOneGame() {
		int guessCount = 0;
		int number = RandomGenerator.getInstance().nextInt(MIN_NUM, MAX_NUM);
		int guess;
		guess = readInt("Take a guess");
		while (guess > MAX_NUM || guess < MIN_NUM) {
			guess = readInt("Please guess between " + MIN_NUM + " and " + MAX_NUM + ": ");
		}
		while (guess != number) {
			while (guess > MAX_NUM && guess < MIN_NUM) {
				guess = readInt("Please guess between " + MIN_NUM + " and " + MAX_NUM + ": ");
			}
			if (guess < number) {
				guess = readInt("Your guess is too small, try again");
			} else if (guess > number) {
				guess = readInt("Your guess is too big, try again");
			}
			guessCount++;
		}
		if (guess == number) {
			println("You got my number!");
			println();
		}
		if (guessCount > maxGuess) {
			maxGuess = guessCount;
		}
		if (guessCount < minGuess) {
			minGuess = guessCount;
		}
	}

	/*
	 * This method shows the overall statistics of the games played
	 * 
	 */
	private void displayStats() {
		println("Statistics: ");
		if (gameCount == 1) {
			println(gameCount + " game played");
		} else {
			println(gameCount + " games played");
		}
		if (gameCount > 0) {
			println("Your best game: " + minGuess + " guesses.");
			println("Your worst game: " + maxGuess + " guesses.");
		}
	}

}
