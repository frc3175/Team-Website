
import java.awt.Color;

import acm.graphics.GOval;
import acm.program.GraphicsProgram;


/*
 * This Java class creates the ball
 * 
 */
public class Ball extends GOval {
	
	
	/*
	 * Constructor for the ball according to the dimensions
	 * 
	 */
	public Ball(int d, int d1) {
		super(d, d1);
	}
	
}