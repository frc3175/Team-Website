import acm.program.ConsoleProgram;
import acm.util.RandomGenerator;

public class FunGame extends ConsoleProgram {

	private static final int MIN_NUM = 1;
	private static final int MAX_NUM = 10;

	private int guess;

	public void run() {
		boolean playTheGame = readBoolean("Would you like to play the game? ", "yes", "no");
		guess = RandomGenerator.getInstance().nextInt(MIN_NUM, MAX_NUM);
		println("Happy birthday Blake!");
		if (playTheGame) {
			playTheGame();
		}
	}

	private void playTheGame() {
		int guess = readInt("Your guess? ");
		while (guess != this.guess) {
			if (guess < this.guess) {
				guess = readInt("Too small");
			} else if (guess > this.guess) {
				guess = readInt("Too big");
			}
		}
		if (guess == this.guess) {
			println("You Win");
		}
	}

}
